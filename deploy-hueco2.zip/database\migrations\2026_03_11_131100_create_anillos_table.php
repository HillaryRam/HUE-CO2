<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('anillos', function (Blueprint $table) {
            $table->id('anillo_id');  // Esto crea 'id' como PRIMARY KEY
            $table->string('nombre');
            $table->integer('orden');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('anillos');
    }
};
